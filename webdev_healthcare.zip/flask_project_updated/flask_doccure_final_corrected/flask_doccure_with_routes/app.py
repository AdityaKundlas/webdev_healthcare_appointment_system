from flask import Flask, render_template
import os

app = Flask(__name__)

# Ensure the static folder is correctly set
app.static_folder = 'static'

# Dynamic routes for all pages

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/add_billing")
def add_billing():
    return render_template("add_billing.html")

@app.route("/add_prescription")
def add_prescription():
    return render_template("add_prescription.html")

@app.route('/admin')
def admin_index():
    return render_template('admin/index.html')

@app.route("/appointments")
def appointments():
    return render_template("appointments.html")

@app.route("/booking")
def booking():
    return render_template("booking.html")

@app.route("/calendar")
def calendar():
    return render_template("calendar.html")

@app.route("/change_password")
def change_password():
    return render_template("change_password.html")

@app.route("/checkout")
def checkout():
    return render_template("checkout.html")

@app.route("/doctor_change_password")
def doctor_change_password():
    return render_template("doctor_change_password.html")

@app.route("/doctor_dashboard")
def doctor_dashboard():
    return render_template("doctor_dashboard.html")

@app.route("/doctor_profile_settings")
def doctor_profile_settings():
    return render_template("doctor_profile_settings.html")

@app.route("/doctor_profile")
def doctor_profile():
    return render_template("doctor_profile.html")

@app.route("/doctor_register")
def doctor_register():
    return render_template("doctor_register.html")

@app.route("/edit_billing")
def edit_billing():
    return render_template("edit_billing.html")

@app.route("/edit_prescription")
def edit_prescription():
    return render_template("edit_prescription.html")

@app.route("/forgot_password")
def forgot_password():
    return render_template("forgot_password.html")

@app.route("/index_2")
def index_2():
    return render_template("index_2.html")

@app.route("/index")
def index():
    return render_template("index.html")

@app.route("/login")
def login():
    return render_template("login.html")

@app.route("/my_patients")
def my_patients():
    return render_template("my_patients.html")

@app.route("/patient_dashboard")
def patient_dashboard():
    return render_template("patient_dashboard.html")

@app.route("/patient_profile")
def patient_profile():
    return render_template("patient_profile.html")

@app.route("/privacy_policy")
def privacy_policy():
    return render_template("privacy_policy.html")

@app.route("/profile_settings")
def profile_settings():
    return render_template("profile_settings.html")

@app.route("/register")
def register():
    return render_template("register.html")

@app.route("/reviews")
def reviews():
    return render_template("reviews.html")

@app.route("/schedule_timings")
def schedule_timings():
    return render_template("schedule_timings.html")

@app.route("/search")
def search():
    return render_template("search.html")

@app.route("/social_media")
def social_media():
    return render_template("social_media.html")

@app.route("/term_condition")
def term_condition():
    return render_template("term_condition.html")

# Routes for admin pages

admin_template_path = os.path.join("templates", "admin")
admin_pages = []
if os.path.exists(admin_template_path):
    admin_pages = [file for file in os.listdir(admin_template_path) if file.endswith(".html")]

    def create_admin_route(page):
        route_name = page.replace(".html", "")
        def admin_page():
            return render_template(f"admin/{page}")
        admin_page.__name__ = f"admin_{route_name}"
        app.route(f"/admin/{route_name}")(admin_page)

    for admin_page in admin_pages:
        create_admin_route(admin_page)
else:
    print(f"Directory {admin_template_path} does not exist")

# Ensure admin_index route exists if admin/index.html exists
if "index.html" in admin_pages:
    @app.route("/admin")
    @app.route("/admin/index")
    def admin_index():
        return render_template("admin/index.html")

if __name__ == "__main__":
    app.run(debug=True)